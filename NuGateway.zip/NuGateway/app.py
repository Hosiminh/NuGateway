from flask import Flask, render_template, jsonify, request, session, redirect, url_for, make_response
from flask_socketio import SocketIO, emit
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from functools import wraps
import json
import os
import socket
import uuid
import serial.tools.list_ports
import logging
from datetime import datetime
from config import config_manager
from logger import setup_logging
from relay_control import relay_controller, manual_control, get_relay_states
from alarm_system import AlarmSystem
from modbus_reader import ModbusReader

# -------------------- Logging --------------------
setup_logging(
    log_level=config_manager.get('log_level', 'INFO'),
    log_file=config_manager.get('log_file', 'nugateway.log')
)
logger = logging.getLogger(__name__)

# -------------------- Flask app --------------------
app = Flask(__name__, template_folder="templates", static_folder="static")
app.config['SECRET_KEY'] = os.urandom(24)

# SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# -------------------- Systems --------------------
alarm_system = AlarmSystem(config_manager)

# Initialize Modbus Reader for MPPT control (tek sÃ¼reÃ§ RS485â€™e eriÅŸsin)
try:
    USE_INTERNAL_MODBUS = config_manager.get('modbus_in_flask', False)
    modbus_reader = ModbusReader(
        config_manager.get('serial_port'),
        baudrate=config_manager.get('baudrate'),
        timeout=config_manager.get('timeout')
    )

    if USE_INTERNAL_MODBUS:
        modbus_reader.connect()
        logger.info('âœ… Modbus Reader initialized and connected in Flask')
    else:
        modbus_reader = None
        logger.info('â„¹ï¸ Using external Modbus service (Flask will not open serial)')

except Exception as e:
    logger.error(f"âŒ Failed to initialize Modbus Reader: {e}")
    modbus_reader = None

# Servisin yazdÄ±ÄŸÄ± sensors.json yolu (gerekirse burayÄ± mutlak yola Ã§evir)
SENSORS_PATH = os.path.join(os.path.dirname(__file__), "sensors.json")
# Ã–rn: SENSORS_PATH = "/var/lib/nugateway/sensors.json"

# -------------------- Auth Decorator --------------------
def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not config_manager.get('enable_auth', False):
            return f(*args, **kwargs)
        # Header token
        token = request.headers.get('X-API-Token')
        if token and token == config_manager.get('api_token', ''):
            return f(*args, **kwargs)
        # Session
        if session.get('authenticated'):
            return f(*args, **kwargs)
        return jsonify({"error": "Unauthorized"}), 401
    return decorated

# -------------------- Web Routes --------------------
@app.route("/")
def root():
    return render_template("dashboard.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/devices")
def devices():
    return render_template("devices.html")

@app.route("/mppt-control")
def mppt_control():
    return render_template("mppt_control.html")

@app.route("/settings")
def settings_page():
    return render_template("settings.html")

@app.route("/relay-control")
def relay_control_page():
    return render_template("relay_control.html")

@app.route("/automation")
def automation_page():
    return render_template("automation.html")

# -------------------- APIs --------------------
@app.route("/api/sensors")
def api_sensors():
    """Return the latest sensors.json with no-cache headers"""
    try:
        with open(SENSORS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        data = {"error": "sensors.json not found", "path": SENSORS_PATH}
    except Exception as e:
        data = {"error": f"read error: {e}"}

    resp = make_response(jsonify(data), 200)
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    return resp

# Frontend bazÄ± yerlerde /sensors Ã§aÄŸÄ±rdÄ±ÄŸÄ± iÃ§in alias rota:
@app.route("/sensors")
def sensors_alias():
    return api_sensors()

@app.route('/api/relays')
@requires_auth
def api_relays():
    """Get current relay states"""
    return jsonify(get_relay_states())

@app.route('/api/relay/<name>', methods=['POST'])
@requires_auth
def api_relay_control(name):
    """Control individual relay"""
    try:
        data = request.get_json()
        state = data.get('state', False)
        if manual_control(name, state):
            socketio.emit('relay_update', {'name': name, 'state': state})
            return jsonify({"status": "ok", "relay": name, "state": state})
        else:
            return jsonify({"error": "Failed to control relay"}), 500
    except Exception as e:
        logger.error(f"Relay control error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/alarms/active')
@requires_auth
def api_active_alarms():
    return jsonify(alarm_system.get_active_alarms())

@app.route('/api/alarms/history')
@requires_auth
def api_alarm_history():
    limit = request.args.get('limit', 50, type=int)
    return jsonify(alarm_system.get_alarm_history(limit))

@app.route('/api/alarms/clear', methods=['POST'])
@requires_auth
def api_clear_alarms():
    data = request.get_json()
    sensor = data.get('sensor')
    alarm_system.clear_alarms(sensor)
    return jsonify({"status": "ok"})

# ---- MPPT Control ----
@app.route('/api/mppt/status')
@limiter.limit("60 per minute")
@requires_auth
def api_mppt_status():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        mppt_data = modbus_reader.read_mppt_data()
        if mppt_data:
            return jsonify({"status": "ok", "data": mppt_data, "timestamp": datetime.now().isoformat()})
        else:
            return jsonify({"error": "Failed to read MPPT data"}), 500
    except Exception as e:
        logger.error(f"MPPT status error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/dimming', methods=['GET', 'POST'])
@requires_auth
def api_mppt_dimming():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        if request.method == 'GET':
            dim_reg = modbus_reader.read_registers(0x0A, 0x9041, 1, function_code=0x03)
            if dim_reg:
                percentage = dim_reg[0] * 10
                return jsonify({"percentage": percentage})
            return jsonify({"error": "Failed to read dimming"}), 500
        else:
            data = request.get_json()
            percentage = data.get('percentage', 0)
            if not 0 <= percentage <= 100:
                return jsonify({"error": "Percentage must be 0-100"}), 400
            success = modbus_reader.set_mppt_dimming(percentage)
            if success:
                socketio.emit('mppt_update', {'type': 'dimming', 'percentage': percentage})
                return jsonify({"status": "ok", "percentage": percentage})
            return jsonify({"error": "Failed to set dimming"}), 500
    except Exception as e:
        logger.error(f"MPPT dimming error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/rtc', methods=['GET', 'POST'])
@requires_auth
def api_mppt_rtc():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        if request.method == 'GET':
            rtc = modbus_reader.get_mppt_rtc()
            if rtc:
                return jsonify(rtc)
            return jsonify({"error": "Failed to read RTC"}), 500
        else:
            data = request.get_json()
            success = modbus_reader.set_mppt_rtc(
                year=data.get('year', 25),
                month=data.get('month', 1),
                day=data.get('day', 1),
                hour=data.get('hour', 0),
                minute=data.get('minute', 0),
                second=data.get('second', 0)
            )
            if success:
                socketio.emit('mppt_update', {'type': 'rtc', 'data': data})
                return jsonify({"status": "ok"})
            return jsonify({"error": "Failed to set RTC"}), 500
    except Exception as e:
        logger.error(f"MPPT RTC error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/timer', methods=['POST'])
@requires_auth
def api_mppt_timer():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        data = request.get_json()
        success = modbus_reader.set_mppt_timer(
            timer_num=data.get('timer_num', 1),
            duration_index=data.get('duration_index', 0),
            dimming_index=data.get('dimming_index', 5)
        )
        if success:
            socketio.emit('mppt_update', {
                'type': 'timer',
                'timer_num': data.get('timer_num', 1),
                'duration_index': data.get('duration_index', 0),
                'dimming_index': data.get('dimming_index', 5)
            })
            return jsonify({"status": "ok"})
        return jsonify({"error": "Failed to set timer"}), 500
    except Exception as e:
        logger.error(f"MPPT timer error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/schedule', methods=['POST'])
@requires_auth
def api_mppt_schedule():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        data = request.get_json()
        success = modbus_reader.set_mppt_timed_schedule(
            period_num=data.get('period_num', 1),
            start_h=data.get('start_h', 0),
            start_m=data.get('start_m', 0),
            start_s=data.get('start_s', 0),
            off_h=data.get('off_h', 0),
            off_m=data.get('off_m', 0),
            off_s=data.get('off_s', 0)
        )
        if success:
            socketio.emit('mppt_update', {'type': 'schedule', 'period_num': data.get('period_num', 1)})
            return jsonify({"status": "ok"})
        return jsonify({"error": "Failed to set schedule"}), 500
    except Exception as e:
        logger.error(f"MPPT schedule error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/battery', methods=['POST'])
@requires_auth
def api_mppt_battery():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        data = request.get_json()
        success = modbus_reader.set_battery_settings(
            lvd_voltage=data.get('lvd', 11.1),
            lvr_voltage=data.get('lvr', 12.6),
            boost_voltage=data.get('boost', 14.4),
            float_voltage=data.get('float', 13.8)
        )
        if success:
            socketio.emit('mppt_update', {'type': 'battery_settings'})
            return jsonify({"status": "ok"})
        return jsonify({"error": "Failed to set battery settings"}), 500
    except Exception as e:
        logger.error(f"MPPT battery settings error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/timing-control', methods=['POST'])
@requires_auth
def api_mppt_timing_control():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        data = request.get_json()
        enable = data.get('enable', False)
        success = modbus_reader.enable_timing_control(enable)
        if success:
            return jsonify({"status": "ok", "enabled": enable})
        return jsonify({"error": "Failed to toggle timing control"}), 500
    except Exception as e:
        logger.error(f"MPPT timing control error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/factory-reset', methods=['POST'])
@requires_auth
def api_mppt_factory_reset():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        data = request.get_json()
        if not data.get('confirm', False):
            return jsonify({"error": "Confirmation required"}), 400
        success = modbus_reader.factory_reset_mppt()
        if success:
            logger.warning("âš ï¸ MPPT factory reset executed")
            return jsonify({"status": "ok", "message": "Factory reset completed"})
        return jsonify({"error": "Failed to reset"}), 500
    except Exception as e:
        logger.error(f"MPPT factory reset error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/mppt/clear-stats', methods=['POST'])
@requires_auth
def api_mppt_clear_stats():
    if not modbus_reader:
        return jsonify({"error": "Modbus reader not available"}), 503
    try:
        success = modbus_reader.clear_statistics_mppt()
        if success:
            return jsonify({"status": "ok", "message": "Statistics cleared"})
        return jsonify({"error": "Failed to clear statistics"}), 500
    except Exception as e:
        logger.error(f"MPPT clear stats error: {e}")
        return jsonify({"error": str(e)}), 500

# ---- Settings / Network / Serial ----
@app.route("/api/settings", methods=['GET'])
@requires_auth
def api_get_settings():
    return jsonify(config_manager.to_dict())

@app.route("/api/settings", methods=['POST'])
@requires_auth
def api_save_settings():
    try:
        data = request.get_json()
        for key, value in data.items():
            config_manager.set(key, value)
        return jsonify({"status": "ok"})
    except Exception as e:
        logger.error(f"Settings save error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/network-info")
def api_network_info():
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
                        for ele in range(0, 2*6, 8)][::-1])
        return jsonify({"hostname": hostname, "ip": ip, "mac": mac})
    except Exception as e:
        logger.error(f"Network info error: {e}")
        return jsonify({"hostname": "unknown","ip": "0.0.0.0","mac": "00:00:00:00:00:00"})

@app.route("/api/serial-ports")
def api_serial_ports():
    try:
        ports = [port.device for port in serial.tools.list_ports.comports()]
        return jsonify({"ports": ports})
    except Exception as e:
        logger.error(f"Serial ports error: {e}")
        return jsonify({"ports": []})

@app.route("/api/stats")
@requires_auth
def api_stats():
    try:
        modbus_ok = False
        try:
            modbus_ok = bool(modbus_reader and getattr(modbus_reader, 'serial', None) and modbus_reader.serial.is_open)
        except Exception:
            modbus_ok = False
        stats = {
            "uptime": "N/A",
            "total_readings": 0,
            "active_alarms": len(alarm_system.get_active_alarms()),
            "mqtt_connected": False,
            "modbus_connected": modbus_ok,
            "last_update": datetime.now().isoformat()
        }
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({"error": str(e)}), 500

# -------------------- Auth APIs --------------------
@app.route("/api/login", methods=['POST'])
@limiter.limit("5 per minute")
def api_login():
    if not config_manager.get('enable_auth', False):
        return jsonify({"error": "Authentication not enabled"}), 400
    data = request.get_json()
    token = data.get('token', '')
    if token == config_manager.get('api_token', ''):
        session['authenticated'] = True
        return jsonify({"status": "ok", "message": "Authenticated"})
    else:
        return jsonify({"error": "Invalid token"}), 401

@app.route("/api/logout", methods=['POST'])
def api_logout():
    session.pop('authenticated', None)
    return jsonify({"status": "ok", "message": "Logged out"})

# -------------------- Socket.IO --------------------
@socketio.on('connect')
def handle_connect():
    logger.info(f"Client connected: {request.sid}")
    emit('connected', {'message': 'Connected to nuGateway'})

@socketio.on('disconnect')
def handle_disconnect():
    logger.info(f"Client disconnected: {request.sid}")

@socketio.on('request_update')
def handle_update_request():
    try:
        with open(SENSORS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        data['timestamp'] = datetime.now().isoformat()
        emit('sensor_update', data)
    except Exception as e:
        logger.error(f"Update request error: {e}")

@socketio.on('request_mppt_update')
def handle_mppt_update_request():
    if not modbus_reader:
        emit('error', {'message': 'Modbus reader not available'})
        return
    try:
        mppt_data = modbus_reader.read_mppt_data()
        if mppt_data:
            emit('mppt_data', mppt_data)
        else:
            emit('error', {'message': 'Failed to read MPPT data'})
    except Exception as e:
        logger.error(f"MPPT update request error: {e}")
        emit('error', {'message': str(e)})

# Background task to broadcast sensor updates
def background_sensor_broadcast():
    while True:
        try:
            socketio.sleep(5)  # every 5s
            # sensors
            try:
                with open(SENSORS_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                data['timestamp'] = datetime.now().isoformat()
                socketio.emit('sensor_update', data)  # no broadcast kw
            except FileNotFoundError:
                pass
            # mppt
            if modbus_reader:
                mppt_data = modbus_reader.read_mppt_data()
                if mppt_data:
                    socketio.emit('mppt_data', mppt_data)  # no broadcast kw
        except Exception as e:
            logger.error(f"Broadcast error: {e}")
            socketio.sleep(5)

# -------------------- Error Handlers --------------------
@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal error: {error}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(429)
def ratelimit_handler(e):
    return jsonify({"error": "Rate limit exceeded"}), 429

# -------------------- Teardown --------------------
@app.teardown_appcontext
def shutdown_session(exception=None):
    try:
        if modbus_reader and getattr(modbus_reader, 'serial', None) and modbus_reader.serial.is_open:
            modbus_reader.disconnect()
    except Exception:
        pass

# -------------------- Main --------------------
if __name__ == "__main__":
    logger.info("ðŸš€ nuGateway Flask app starting...")
    logger.info(f"Authentication: {'Enabled' if config_manager.get('enable_auth', False) else 'Disabled'}")
    try:
        modbus_ok = bool(modbus_reader and getattr(modbus_reader, 'serial', None) and modbus_reader.serial.is_open)
    except Exception:
        modbus_ok = False
    logger.info(f"Modbus: {'Connected' if modbus_ok else 'Disconnected'}")

    socketio.start_background_task(background_sensor_broadcast)

    # Reloader kapalÄ± -> duplicate endpoint hatasÄ± olmaz
    socketio.run(
        app,
        debug=True,
        use_reloader=False,
        host="0.0.0.0",
        port=5000,
        allow_unsafe_werkzeug=True
    )